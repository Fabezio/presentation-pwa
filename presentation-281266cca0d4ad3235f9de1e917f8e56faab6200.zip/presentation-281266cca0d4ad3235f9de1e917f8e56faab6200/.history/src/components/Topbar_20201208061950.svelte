<style>
  header {
    display: flex;
    justify-content: space-between;
    padding: 2px;
  }
</style>

<header>
  <slot />
</header>
