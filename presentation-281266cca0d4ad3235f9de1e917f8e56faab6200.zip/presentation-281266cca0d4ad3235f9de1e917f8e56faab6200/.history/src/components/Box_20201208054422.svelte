<script>
  export let tag = "";
</script>

<div class="box">
  <div class="thumbnail">
    <i class="icon rounded bg-blue white far fa-calendar-alt fa-3x " />
  </div>
  <span class="tag">7</span>
</div>
