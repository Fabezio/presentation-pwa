<script>
  import Topbar from "../components/Topbar.svelte";
  let email = "";
  let password = "";
</script>

<style>
  .brand {
    color: #2962ff;
    font-weight: bold;
  }

  input {
    width: 100%;
    margin: 1rem 0;
    padding: 1rem 0;
  }
  .bg-blue {
    width: 100%;
    background-color: #2962ff;
    color: white;
  }
  button {
    display: block;
    border: none;
    padding: 1rem;
    margin: 1rem 0;
  }
</style>

<Topbar>
  <div class="brand">Projet</div>
  <div class="close">&times;</div>
</Topbar>
<div class="panel">
  <h1>S'identifier</h1>
  <p>ou <a href="#">s'inscrire sur <span class="brand">Projet</span></a></p>
  <form action="">
    <input type="email" bind:value={email} placeholder="E-mail" />
    <input type="password" bind:value={password} placeholder="Mot de passe" />
    <button class="bg-blue" type="submit">S'identifier</button>
  </form>
  <a href="#">Mot de passe oublié?</a>
  <button class="bg-blue">S'identifier avec l'empreinte digitale</button>
</div>
