<div class="topbar">

    <div>Projet</div><div>X</div></p>
</div>

<style>
    .topbar
    {
        display: flex;
        justify-content: space-between;
    }
</style>


