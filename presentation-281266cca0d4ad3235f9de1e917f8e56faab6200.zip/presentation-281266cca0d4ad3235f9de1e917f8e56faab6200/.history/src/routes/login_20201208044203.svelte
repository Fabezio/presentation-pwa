<style>
  .topbar {
    display: flex;
    justify-content: space-between;
  }
</style>

<div class="topbar">
  <div>Projet</div>
  <div>X</div>
</div>
